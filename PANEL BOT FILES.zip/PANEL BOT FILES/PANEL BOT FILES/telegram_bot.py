import telebot
import json
import os
import random
import string
import time
from datetime import datetime, timedelta

# ========== HARDCODED CONFIGURATION ==========
BOT_TOKEN = "8640367692:AAE-Ip_Wd8nUanuRLbcRb4UMroW96RqsL2A"
OWNER_ID = 1434287051

bot = telebot.TeleBot(BOT_TOKEN)

# ========== JSON DATA STORAGE ==========
DATA_DIR = "bot_data"
os.makedirs(DATA_DIR, exist_ok=True)

KEYS_FILE = os.path.join(DATA_DIR, "keys.json")
ADMINS_FILE = os.path.join(DATA_DIR, "admins.json")
ACTIVE_SESSIONS_FILE = os.path.join(DATA_DIR, "active_sessions.json")

def load_json(file_path, default=None):
    if default is None:
        default = {}
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except:
            return default
    return default

def save_json(file_path, data):
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=2, default=str)

def get_keys():
    return load_json(KEYS_FILE, {})

def save_keys(keys):
    save_json(KEYS_FILE, keys)

def get_admins():
    return load_json(ADMINS_FILE, {})

def save_admins(admins):
    save_json(ADMINS_FILE, admins)

def get_active_sessions():
    return load_json(ACTIVE_SESSIONS_FILE, {})

def save_active_sessions(sessions):
    save_json(ACTIVE_SESSIONS_FILE, sessions)

# ========== HELPER FUNCTIONS ==========

def is_owner(user_id):
    return str(user_id) == str(OWNER_ID)

def is_admin(user_id):
    if is_owner(user_id):
        return True
    admins = get_admins()
    return str(user_id) in admins

def parse_duration(duration_str):
    duration_str = duration_str.lower().strip()
    if duration_str.endswith('h'):
        hours = int(duration_str[:-1])
        return timedelta(hours=hours)
    elif duration_str.endswith('d'):
        days = int(duration_str[:-1])
        return timedelta(days=days)
    elif duration_str.endswith('m'):
        minutes = int(duration_str[:-1])
        return timedelta(minutes=minutes)
    return None

def generate_key():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

def format_expiry_ist(timestamp_ms):
    dt = datetime.fromtimestamp(timestamp_ms / 1000)
    dt_ist = dt + timedelta(hours=5, minutes=30)
    return dt_ist.strftime("%Y-%m-%d %H:%M:%S IST")

# ========== COMMANDS ==========

@bot.message_handler(commands=['start'])
def start_cmd(message):
    user_id = str(message.from_user.id)
    if is_owner(user_id):
        bot.reply_to(message,
            f"👋 Welcome Owner!\n\n"
            f"📋 Commands:\n"
            f"/gen - Generate Key (1 device limit)\n"
            f"/genlimit - Generate Key with custom device limit\n"
            f"/mykeys - View your generated keys\n"
            f"/deletekey KEY - Delete your key\n"
            f"/resetkey KEY - Force logout user\n"
            f"/delallkey - Delete ALL keys (Owner only)\n"
            f"/delmyallkey - Delete all keys you generated\n"
            f"/delallunusedkey - Delete ALL unused keys (Owner only)\n"
            f"/delmyallunusedkey - Delete your unused keys\n"
            f"/allkeys - View all keys\n"
            f"/addadmin USER_ID - Add admin\n"
            f"/removeadmin USER_ID - Remove admin\n"
            f"/admins - View all admins")
    elif is_admin(user_id):
        bot.reply_to(message,
            f"👋 Welcome Admin!\n\n"
            f"📋 Commands:\n"
            f"/gen - Generate Key (1 device limit)\n"
            f"/mykeys - View your generated keys\n"
            f"/deletekey KEY - Delete your key\n"
            f"/resetkey KEY - Force logout user\n"
            f"/delmyallkey - Delete all keys you generated\n"
            f"/delmyallunusedkey - Delete your unused keys")
    else:
        bot.reply_to(message, "❌ You don't have access. Contact admin.")

@bot.message_handler(commands=['gen'])
def generate_keys(message):
    user_id = str(message.from_user.id)
    if not is_admin(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    try:
        parts = message.text.split()
        if len(parts) == 2:
            duration_str = parts[1]
            quantity = 1
        elif len(parts) == 3:
            duration_str = parts[1]
            quantity = int(parts[2])
        else:
            bot.reply_to(message, "Usage: /gen 1h or /gen 1d 5")
            return
        
        if quantity < 1 or quantity > 100:
            bot.reply_to(message, "Quantity must be between 1 and 100")
            return
        
        duration = parse_duration(duration_str)
        if not duration:
            bot.reply_to(message, "Invalid duration. Use: 1h, 2d, 30m")
            return
        
        keys_generated = []
        now = int(time.time() * 1000)
        expiry = int((datetime.now() + duration).timestamp() * 1000)
        
        keys = get_keys()
        
        for _ in range(quantity):
            key = generate_key()
            keys[key] = {
                'key': key,
                'generated_by': user_id,
                'generated_at': now,
                'expiry_at': expiry,
                'device_limit': 1,
                'is_active': 1,
                'is_used': 0
            }
            keys_generated.append(key)
        
        save_keys(keys)
        
        # Auto-delete unused keys older than 7 days
        auto_expiry = int((datetime.now() - timedelta(days=7)).timestamp() * 1000)
        keys = get_keys()
        for k, v in list(keys.items()):
            if v.get('is_used') == 0 and v.get('generated_at', 0) < auto_expiry and v.get('is_active', 0) == 1:
                keys[k]['is_active'] = 0
        save_keys(keys)
        
        expiry_readable = format_expiry_ist(expiry)
        duration_display = duration_str.lower()
        
        if quantity == 1:
            key = keys_generated[0]
            response = (
                f"✅ Key Generated!\n\n"
                f"🔑 Login Key: <code>{key}</code>\n"
                f"⏱️ Duration: {duration_display}\n"
                f"📅 Expiry: {expiry_readable}\n"
                f"📱 Device Limit: 1 device"
            )
        else:
            key_list = "\n".join([f"<code>{k}</code>" for k in keys_generated])
            response = (
                f"✅ {quantity} Keys Generated!\n\n"
                f"🔑 Login Keys:\n{key_list}\n\n"
                f"⏱️ Duration: {duration_display}\n"
                f"📅 Expiry: {expiry_readable}\n"
                f"📱 Device Limit: 1 device per key\n"
                f"Unused keys auto-delete after 7 days."
            )
        
        bot.reply_to(message, response, parse_mode='HTML')
        
    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

@bot.message_handler(commands=['genlimit'])
def generate_limited_keys(message):
    user_id = str(message.from_user.id)
    
    # Owner only command
    if not is_owner(user_id):
        bot.reply_to(message, "❌ This command is only for Owner!")
        return
    
    try:
        parts = message.text.split()
        if len(parts) == 3:
            duration_str = parts[1]
            device_limit = int(parts[2])
            quantity = 1
        elif len(parts) == 4:
            duration_str = parts[1]
            quantity = int(parts[2])
            device_limit = int(parts[3])
        else:
            bot.reply_to(message, "Usage: /genlimit 24h 3 or /genlimit 24h 5 3")
            return
        
        if quantity < 1 or quantity > 100:
            bot.reply_to(message, "Quantity must be between 1 and 100")
            return
        
        if device_limit < 1 or device_limit > 100:
            bot.reply_to(message, "Device limit must be between 1 and 100")
            return
        
        duration = parse_duration(duration_str)
        if not duration:
            bot.reply_to(message, "Invalid duration. Use: 1h, 2d, 30m")
            return
        
        keys_generated = []
        now = int(time.time() * 1000)
        expiry = int((datetime.now() + duration).timestamp() * 1000)
        
        keys = get_keys()
        
        for _ in range(quantity):
            key = generate_key()
            keys[key] = {
                'key': key,
                'generated_by': user_id,
                'generated_at': now,
                'expiry_at': expiry,
                'device_limit': device_limit,
                'is_active': 1,
                'is_used': 0
            }
            keys_generated.append(key)
        
        save_keys(keys)
        
        expiry_readable = format_expiry_ist(expiry)
        duration_display = duration_str.lower()
        
        if quantity == 1:
            key = keys_generated[0]
            response = (
                f"✅ Key Generated!\n\n"
                f"🔑 Login Key: <code>{key}</code>\n"
                f"⏱️ Duration: {duration_display}\n"
                f"📅 Expiry: {expiry_readable}\n"
                f"📱 Device Limit: {device_limit} device(s)"
            )
        else:
            key_list = "\n".join([f"<code>{k}</code>" for k in keys_generated])
            response = (
                f"✅ {quantity} Keys Generated!\n\n"
                f"🔑 Login Keys:\n{key_list}\n\n"
                f"⏱️ Duration: {duration_display}\n"
                f"📅 Expiry: {expiry_readable}\n"
                f"📱 Device Limit: {device_limit} device(s) per key\n"
                f"Unused keys auto-delete after 7 days."
            )
        
        bot.reply_to(message, response, parse_mode='HTML')
        
    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

@bot.message_handler(commands=['mykeys'])
def my_keys(message):
    user_id = str(message.from_user.id)
    if not is_admin(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    keys = get_keys()
    now = int(time.time() * 1000)
    response = "🔑 Your Keys:\n\n"
    count = 0
    
    for key, data in keys.items():
        if data.get('generated_by') == user_id:
            count += 1
            if data.get('is_active') and data.get('expiry_at', 0) > now:
                status = "🔒 In Use" if data.get('is_used') else "✅ Active"
            else:
                status = "⏰ Expired"
            expiry_readable = format_expiry_ist(data.get('expiry_at', 0))
            device_limit = data.get('device_limit', 1)
            limit_text = f"{device_limit} device(s)"
            response += f"• <code>{key}</code>\n  Expires: {expiry_readable}\n  Status: {status}\n  Device Limit: {limit_text}\n\n"
            if count >= 50:
                break
    
    if count == 0:
        bot.reply_to(message, "No keys generated yet.")
    else:
        bot.reply_to(message, response[:4000], parse_mode='HTML')

@bot.message_handler(commands=['deletekey'])
def delete_key(message):
    user_id = str(message.from_user.id)
    if not is_admin(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    try:
        key = message.text.split()[1]
    except:
        bot.reply_to(message, "Usage: /deletekey KEY")
        return
    
    keys = get_keys()
    
    if key not in keys:
        bot.reply_to(message, f"Key <code>{key}</code> not found!", parse_mode='HTML')
        return
    
    if not is_owner(user_id) and keys[key].get('generated_by') != user_id:
        bot.reply_to(message, "❌ You can only delete keys you generated!")
        return
    
    if keys[key].get('is_used'):
        bot.reply_to(message, f"❌ Cannot delete used key <code>{key}</code>!", parse_mode='HTML')
        return
    
    # Delete active session if exists
    sessions = get_active_sessions()
    if key in sessions:
        del sessions[key]
        save_active_sessions(sessions)
    
    keys[key]['is_active'] = 0
    save_keys(keys)
    
    bot.reply_to(message, f"✅ Key <code>{key}</code> deleted!", parse_mode='HTML')

@bot.message_handler(commands=['resetkey'])
def reset_key(message):
    user_id = str(message.from_user.id)
    if not is_admin(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    try:
        key = message.text.split()[1]
    except:
        bot.reply_to(message, "Usage: /resetkey KEY")
        return
    
    keys = get_keys()
    
    if key not in keys:
        bot.reply_to(message, f"Key <code>{key}</code> not found!", parse_mode='HTML')
        return
    
    if not is_owner(user_id) and keys[key].get('generated_by') != user_id:
        bot.reply_to(message, "❌ You can only reset keys you generated!")
        return
    
    # Delete active session
    sessions = get_active_sessions()
    if key in sessions:
        del sessions[key]
        save_active_sessions(sessions)
    
    bot.reply_to(message, f"🔄 Key <code>{key}</code> has been reset. User logged out.", parse_mode='HTML')

@bot.message_handler(commands=['delallkey'])
def delete_all_keys(message):
    user_id = str(message.from_user.id)
    
    if not is_owner(user_id):
        bot.reply_to(message, "❌ Owner only command!")
        return
    
    keys = get_keys()
    total_keys = len(keys)
    
    # Clear all active sessions
    sessions = get_active_sessions()
    sessions.clear()
    save_active_sessions(sessions)
    
    # Delete all keys
    keys.clear()
    save_keys(keys)
    
    bot.reply_to(message, f"✅ All keys deleted!\n\n📊 Total keys deleted: {total_keys}")

@bot.message_handler(commands=['delmyallkey'])
def delete_my_all_keys(message):
    user_id = str(message.from_user.id)
    
    if not is_admin(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    keys = get_keys()
    sessions = get_active_sessions()
    deleted_count = 0
    
    for key, data in list(keys.items()):
        if data.get('generated_by') == user_id:
            # Delete active session
            if key in sessions:
                del sessions[key]
            keys[key]['is_active'] = 0
            deleted_count += 1
    
    save_keys(keys)
    save_active_sessions(sessions)
    
    bot.reply_to(message, f"✅ All your keys deleted!\n\n📊 Total keys deleted: {deleted_count}")

@bot.message_handler(commands=['delallunusedkey'])
def delete_all_unused_keys(message):
    user_id = str(message.from_user.id)
    
    if not is_owner(user_id):
        bot.reply_to(message, "❌ Owner only command!")
        return
    
    keys = get_keys()
    sessions = get_active_sessions()
    deleted_count = 0
    
    for key, data in list(keys.items()):
        if data.get('is_used') == 0 and data.get('is_active') == 1:
            if key in sessions:
                del sessions[key]
            keys[key]['is_active'] = 0
            deleted_count += 1
    
    save_keys(keys)
    save_active_sessions(sessions)
    
    bot.reply_to(message, f"✅ All unused keys deleted!\n\n📊 Total unused keys deleted: {deleted_count}")

@bot.message_handler(commands=['delmyallunusedkey'])
def delete_my_all_unused_keys(message):
    user_id = str(message.from_user.id)
    
    if not is_admin(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    keys = get_keys()
    sessions = get_active_sessions()
    deleted_count = 0
    
    for key, data in list(keys.items()):
        if data.get('generated_by') == user_id and data.get('is_used') == 0 and data.get('is_active') == 1:
            if key in sessions:
                del sessions[key]
            keys[key]['is_active'] = 0
            deleted_count += 1
    
    save_keys(keys)
    save_active_sessions(sessions)
    
    bot.reply_to(message, f"✅ Your unused keys deleted!\n\n📊 Total unused keys deleted: {deleted_count}")

@bot.message_handler(commands=['allkeys'])
def all_keys(message):
    if not is_owner(str(message.from_user.id)):
        bot.reply_to(message, "❌ Owner only command.")
        return
    
    keys = get_keys()
    now = int(time.time() * 1000)
    response = "📊 All Keys:\n\n"
    count = 0
    
    for key, data in list(keys.items())[:30]:
        count += 1
        if data.get('is_active') and data.get('expiry_at', 0) > now:
            status = "🔒 In Use" if data.get('is_used') else "✅ Active"
        else:
            status = "⏰ Expired"
        expiry_readable = format_expiry_ist(data.get('expiry_at', 0))
        device_limit = data.get('device_limit', 1)
        limit_text = f"{device_limit} device(s)"
        response += f"• <code>{key}</code>\n  By: {data.get('generated_by')}\n  Expires: {expiry_readable}\n  Status: {status}\n  Device Limit: {limit_text}\n\n"
    
    if count == 0:
        bot.reply_to(message, "No keys in database.")
    else:
        bot.reply_to(message, response[:4000], parse_mode='HTML')

@bot.message_handler(commands=['addadmin'])
def add_admin(message):
    if not is_owner(str(message.from_user.id)):
        bot.reply_to(message, "❌ Owner only command.")
        return
    
    try:
        new_admin = message.text.split()[1]
    except:
        bot.reply_to(message, "Usage: /addadmin USER_ID")
        return
    
    admins = get_admins()
    if new_admin in admins:
        bot.reply_to(message, f"User <code>{new_admin}</code> is already an admin.", parse_mode='HTML')
        return
    
    admins[new_admin] = {
        'user_id': new_admin,
        'added_by': str(message.from_user.id),
        'added_at': int(time.time() * 1000)
    }
    save_admins(admins)
    bot.reply_to(message, f"✅ User <code>{new_admin}</code> is now an admin!", parse_mode='HTML')

@bot.message_handler(commands=['removeadmin'])
def remove_admin(message):
    if not is_owner(str(message.from_user.id)):
        bot.reply_to(message, "❌ Owner only command.")
        return
    
    try:
        admin_to_remove = message.text.split()[1]
    except:
        bot.reply_to(message, "Usage: /removeadmin USER_ID")
        return
    
    if admin_to_remove == str(OWNER_ID):
        bot.reply_to(message, "❌ Cannot remove owner.")
        return
    
    admins = get_admins()
    if admin_to_remove in admins:
        del admins[admin_to_remove]
        save_admins(admins)
        bot.reply_to(message, f"✅ User <code>{admin_to_remove}</code> is no longer an admin.", parse_mode='HTML')
    else:
        bot.reply_to(message, f"User <code>{admin_to_remove}</code> is not an admin.", parse_mode='HTML')

@bot.message_handler(commands=['admins'])
def list_admins(message):
    if not is_owner(str(message.from_user.id)):
        bot.reply_to(message, "❌ Owner only command.")
        return
    
    admins = get_admins()
    if not admins:
        bot.reply_to(message, "No admins found.")
        return
    
    response = "👥 Admin List:\n\n"
    for admin_id, data in admins.items():
        added_time = datetime.fromtimestamp(data.get('added_at', 0) / 1000).strftime("%Y-%m-%d %H:%M:%S")
        response += f"• User ID: <code>{admin_id}</code>\n  Added by: {data.get('added_by')}\n  Added on: {added_time}\n\n"
    
    bot.reply_to(message, response[:4000], parse_mode='HTML')

# ========== API FUNCTIONS (Called by API Server) ==========

def verify_key_api(key, user_device_id):
    keys = get_keys()
    
    if key not in keys:
        return {"valid": False, "reason": "Key not found"}
    
    key_data = keys[key]
    expiry_ts = key_data.get('expiry_at', 0)
    is_active = key_data.get('is_active', 0)
    device_limit = key_data.get('device_limit', 1)
    now = int(time.time() * 1000)
    
    if is_active == 0:
        return {"valid": False, "reason": "Key has been deleted"}
    
    if expiry_ts < now:
        return {"valid": False, "reason": "Key expired"}
    
    sessions = get_active_sessions()
    current_devices = sessions.get(key, {})
    
    # Check device limit
    active_count = len(current_devices) if isinstance(current_devices, dict) else 0
    
    if user_device_id not in current_devices:
        if active_count >= device_limit:
            return {"valid": False, "reason": f"Key has reached maximum device limit ({device_limit})"}
    
    # Update session
    if key not in sessions:
        sessions[key] = {}
    
    sessions[key][user_device_id] = {
        'login_time': now,
        'last_active': now
    }
    save_active_sessions(sessions)
    
    if key_data.get('is_used') == 0:
        keys[key]['is_used'] = 1
        keys[key]['used_by'] = user_device_id
        keys[key]['used_at'] = now
        save_keys(keys)
    
    return {"valid": True, "expiry": expiry_ts, "expiry_readable": format_expiry_ist(expiry_ts)}

def release_key_session(key, device_id=None):
    sessions = get_active_sessions()
    if key in sessions:
        if device_id and device_id in sessions[key]:
            del sessions[key][device_id]
            if len(sessions[key]) == 0:
                del sessions[key]
        else:
            del sessions[key]
        save_active_sessions(sessions)

print("🤖 Telegram Bot Started (JSON Storage + Device Limit)!")
bot.infinity_polling()